import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, CheckCircle2, ShoppingBag, Trash2 } from 'lucide-react';
import { CartItem } from '../types';

interface ContactSectionProps {
  cart: CartItem[];
  onRemoveFromCart: (id: string) => void;
  onClearCart: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  cart,
  onRemoveFromCart,
  onClearCart
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [intent, setIntent] = useState<'pedido' | 'reserva' | 'duvida'>('pedido');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; email?: string }>({});

  const cartTotal = cart.reduce((sum, item) => sum + item.item.price * item.quantity, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { name?: string; email?: string } = {};

    if (!name.trim()) {
      newErrors.name = 'Por favor, informe seu nome completo.';
    }

    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Informe um endereço de e-mail válido.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    setName('');
    setEmail('');
    setNotes('');
    onClearCart();
  };

  return (
    <section id="contato" className="py-24 sm:py-32 px-6 sm:px-8 max-w-5xl mx-auto border-t border-white/5">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-xs uppercase tracking-widest text-[#EA580C] font-semibold block mb-3">
          Atendimento Direto
        </span>
        <h2 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-white tracking-tight mb-4 text-balance">
          Entre em contato.
        </h2>
        <p className="text-stone-300 text-base font-light">
          Envie sua mensagem ou finalize seu pedido de pizzas artesanais direto com nossa equipe.
        </p>
      </div>

      <div className="bg-[#141211] rounded-3xl border border-white/10 p-8 sm:p-12 shadow-2xl relative overflow-hidden">
        {/* Glow accent */}
        <div 
          className="absolute -top-24 -right-24 w-80 h-80 bg-[#E31837]/10 blur-[90px] rounded-full pointer-events-none" 
          aria-hidden="true" 
        />

        <AnimatePresence mode="wait">
          {submitted ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="py-12 text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-full bg-[#EA580C]/20 border border-[#EA580C]/40 flex items-center justify-center text-[#EA580C] mb-6">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white mb-2">
                Mensagem enviada com sucesso!
              </h3>
              <p className="text-stone-300 text-sm max-w-md mx-auto leading-relaxed mb-6 font-light">
                Obrigado, <strong className="text-white font-medium">{name}</strong>. Recebemos seus dados e entraremos em contato via <strong className="text-white font-medium">{email}</strong> com prioridade.
              </p>

              {cart.length > 0 && (
                <div className="w-full max-w-md bg-stone-900/90 border border-white/10 rounded-2xl p-5 mb-8 text-left text-xs">
                  <div className="font-semibold text-stone-200 uppercase tracking-wider mb-3">
                    Resumo do Pedido Anexado:
                  </div>
                  {cart.map((c) => (
                    <div key={c.item.id} className="flex justify-between py-1 text-stone-300">
                      <span>{c.quantity}x {c.item.name}</span>
                      <span className="font-mono tabular-nums">
                        R$ {(c.item.price * c.quantity).toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                  ))}
                  <div className="border-t border-white/10 mt-3 pt-3 flex justify-between font-semibold text-white">
                    <span>Total estimado</span>
                    <span className="font-mono text-[#EA580C] tabular-nums">
                      R$ {cartTotal.toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                </div>
              )}

              <button
                onClick={handleReset}
                className="px-6 py-2.5 rounded-full text-xs font-semibold text-stone-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
              >
                Enviar nova mensagem
              </button>
            </motion.div>
          ) : (
            <motion.form
              key="form"
              onSubmit={handleSubmit}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
              noValidate
            >
              {/* Selected Order Summary Banner (If items added from menu) */}
              {cart.length > 0 && (
                <div className="bg-stone-900/90 border border-white/10 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 text-xs font-semibold text-white uppercase tracking-wider">
                      <ShoppingBag className="w-4 h-4 text-[#EA580C]" />
                      <span>Pizzas Selecionadas no Cardápio ({cart.length})</span>
                    </div>
                    <button
                      type="button"
                      onClick={onClearCart}
                      className="text-xs text-stone-400 hover:text-red-400 flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Limpar seleção</span>
                    </button>
                  </div>

                  <div className="space-y-2 divide-y divide-white/5 text-sm">
                    {cart.map((cartItem) => (
                      <div key={cartItem.item.id} className="pt-2 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-white font-medium">{cartItem.item.name}</span>
                          <span className="text-xs text-stone-400">({cartItem.quantity}x)</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-stone-300 tabular-nums">
                            R$ {(cartItem.item.price * cartItem.quantity).toFixed(2).replace('.', ',')}
                          </span>
                          <button
                            type="button"
                            onClick={() => onRemoveFromCart(cartItem.item.id)}
                            className="text-stone-400 hover:text-white text-xs"
                            aria-label={`Remover ${cartItem.item.name}`}
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 flex justify-between items-center text-sm font-semibold">
                    <span className="text-stone-300">Subtotal do pedido</span>
                    <span className="font-mono text-[#EA580C] text-base tabular-nums">
                      R$ {cartTotal.toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                </div>
              )}

              {/* Form Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-xs font-semibold uppercase tracking-wider text-stone-300 mb-2">
                    Seu Nome Completo *
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    placeholder="Ex: Gabriel Monteiro"
                    className={`w-full px-4 py-3.5 rounded-xl bg-stone-900 border text-white placeholder-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#E31837] transition-all ${
                      errors.name ? 'border-red-500' : 'border-white/10'
                    }`}
                  />
                  {errors.name && (
                    <p className="mt-1.5 text-xs text-red-400 font-medium">{errors.name}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="email" className="block text-xs font-semibold uppercase tracking-wider text-stone-300 mb-2">
                    Seu E-mail *
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                    }}
                    placeholder="seuemail@exemplo.com"
                    className={`w-full px-4 py-3.5 rounded-xl bg-stone-900 border text-white placeholder-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#E31837] transition-all ${
                      errors.email ? 'border-red-500' : 'border-white/10'
                    }`}
                  />
                  {errors.email && (
                    <p className="mt-1.5 text-xs text-red-400 font-medium">{errors.email}</p>
                  )}
                </div>
              </div>

              {/* Intent Selector */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-stone-300 mb-2">
                  Assunto Principal
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setIntent('pedido')}
                    className={`py-3 px-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer text-center ${
                      intent === 'pedido'
                        ? 'border-[#E31837] bg-[#E31837]/15 text-white'
                        : 'border-white/10 bg-stone-900 text-stone-400 hover:text-white'
                    }`}
                  >
                    Fazer Pedido
                  </button>
                  <button
                    type="button"
                    onClick={() => setIntent('reserva')}
                    className={`py-3 px-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer text-center ${
                      intent === 'reserva'
                        ? 'border-[#E31837] bg-[#E31837]/15 text-white'
                        : 'border-white/10 bg-stone-900 text-stone-400 hover:text-white'
                    }`}
                  >
                    Reserva Especial
                  </button>
                  <button
                    type="button"
                    onClick={() => setIntent('duvida')}
                    className={`py-3 px-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer text-center ${
                      intent === 'duvida'
                        ? 'border-[#E31837] bg-[#E31837]/15 text-white'
                        : 'border-white/10 bg-stone-900 text-stone-400 hover:text-white'
                    }`}
                  >
                    Dúvidas / Outros
                  </button>
                </div>
              </div>

              {/* Message / Notes */}
              <div>
                <label htmlFor="notes" className="block text-xs font-semibold uppercase tracking-wider text-stone-300 mb-2">
                  Mensagem ou Preferências
                </label>
                <textarea
                  id="notes"
                  rows={4}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Alguma observação especial sobre o ponto da massa, restrições ou número de pessoas?"
                  className="w-full px-4 py-3.5 rounded-xl bg-stone-900 border border-white/10 text-white placeholder-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-[#E31837] transition-all resize-none"
                />
              </div>

              {/* Action Button */}
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full text-base font-semibold text-white bg-[#E31837] hover:bg-[#c9122f] active:scale-[0.98] transition-all duration-200 shadow-xl shadow-[#E31837]/25 cursor-pointer"
                >
                  <span>Enviar solicitação</span>
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};
