import React from 'react';
import { motion } from 'motion/react';
import { ArrowDownRight, Flame } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section 
      id="inicio" 
      className="relative min-h-[92vh] flex flex-col justify-between pt-28 pb-12 px-6 sm:px-8 max-w-7xl mx-auto overflow-hidden"
    >
      {/* Background ambient warmth */}
      <div 
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-[#E31837]/10 blur-[130px] rounded-full pointer-events-none -z-10" 
        aria-hidden="true"
      />

      {/* Top Header Statement */}
      <div className="pt-6 sm:pt-10 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#EA580C] font-semibold mb-6"
        >
          <Flame className="w-4 h-4 text-[#EA580C]" />
          <span>Fogo a lenha e fermentação lenta</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="text-5xl sm:text-7xl lg:text-8xl font-serif font-black tracking-tight text-white leading-[1.02] text-balance mb-6"
        >
          A essência da pizza artesanal.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="text-lg sm:text-xl text-stone-300 font-light max-w-2xl leading-relaxed mb-8"
        >
          Massa de 48 horas de maturação natural, assada a 450°C no forno a lenha napolitano.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-wrap items-center gap-4 sm:gap-6"
        >
          <a
            href="#contato"
            className="inline-flex items-center justify-center px-8 py-4 rounded-full text-base font-semibold text-white bg-[#E31837] hover:bg-[#c9122f] active:scale-[0.98] transition-all duration-200 shadow-xl shadow-[#E31837]/25"
          >
            Entrar em contato
          </a>
          <a
            href="#cardapio"
            className="inline-flex items-center gap-2 px-6 py-4 rounded-full text-base font-medium text-stone-300 hover:text-white hover:bg-stone-900/60 border border-white/10 transition-all duration-200"
          >
            <span>Ver cardápio</span>
            <ArrowDownRight className="w-4 h-4 text-[#EA580C]" />
          </a>
        </motion.div>
      </div>

      {/* Hero Visual: ONE monumental, cinematic photograph */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="mt-12 sm:mt-16 relative rounded-2xl sm:rounded-3xl overflow-hidden border border-white/10 shadow-2xl bg-stone-900 group"
      >
        <div className="aspect-[16/9] w-full relative">
          <img
            src="/src/assets/images/hero_pizza_oven_1792173841382.jpg"
            alt="Pizzaiolo retirando pizza artesanal crocante com borda aerada do forno a lenha ardente"
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.02]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0C0A09] via-transparent to-black/20" />
        </div>

        {/* Minimalist discreet caption on the image */}
        <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-xs text-stone-300 backdrop-blur-md bg-black/40 px-5 py-3 rounded-xl border border-white/10">
          <span className="font-medium text-white">Forno a lenha napolitano em brasa viva</span>
          <span className="tabular-nums text-[#EA580C] font-mono">450°C · 90 segundos de cocção</span>
        </div>
      </motion.div>

      {/* Peek invite indicator */}
      <div className="mt-8 flex items-center justify-center">
        <a 
          href="#cardapio" 
          aria-label="Rolar para o cardápio"
          className="text-stone-400 hover:text-white transition-colors flex flex-col items-center gap-2 text-xs uppercase tracking-widest font-medium"
        >
          <span>Conheça a seleção</span>
          <div className="w-px h-8 bg-gradient-to-b from-[#EA580C] to-transparent animate-pulse" />
        </a>
      </div>
    </section>
  );
};
