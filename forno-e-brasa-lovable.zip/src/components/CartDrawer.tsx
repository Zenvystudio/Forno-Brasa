import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Minus, Trash2, ArrowRight, ShoppingBag } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onProceedToContact: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToContact
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  const total = cart.reduce((sum, item) => sum + item.item.price * item.quantity, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm cursor-pointer"
          />

          {/* Drawer Panel */}
          <motion.aside
            role="dialog"
            aria-modal="true"
            aria-label="Seu Pedido"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-0 right-0 bottom-0 z-50 w-full max-w-md bg-[#12100E] border-l border-white/10 shadow-2xl flex flex-col justify-between"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-5 h-5 text-[#EA580C]" />
                <h3 className="text-xl font-serif font-bold text-white">Seu Pedido</h3>
              </div>
              <button
                onClick={onClose}
                className="p-2 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800/50 transition-colors"
                aria-label="Fechar painel do pedido"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4">
              {cart.length === 0 ? (
                <div className="py-20 text-center flex flex-col items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-stone-900 border border-white/5 flex items-center justify-center text-stone-400 mb-4">
                    <ShoppingBag className="w-7 h-7" />
                  </div>
                  <p className="text-white font-serif text-lg mb-1">Seu pedido está vazio</p>
                  <p className="text-stone-400 text-xs max-w-xs font-light">
                    Escolha suas pizzas favoritas em nosso cardápio digital para montar seu pedido.
                  </p>
                </div>
              ) : (
                cart.map((cartItem) => (
                  <div
                    key={cartItem.item.id}
                    className="p-4 rounded-2xl bg-stone-900/80 border border-white/5 flex gap-4 items-center"
                  >
                    <img
                      src={cartItem.item.image}
                      alt={cartItem.item.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-semibold text-white truncate">
                        {cartItem.item.name}
                      </h4>
                      <p className="text-xs text-[#EA580C] font-mono tabular-nums mt-0.5">
                        R$ {cartItem.item.price.toFixed(2).replace('.', ',')}
                      </p>

                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() => onUpdateQuantity(cartItem.item.id, -1)}
                          className="w-6 h-6 rounded-md bg-stone-800 text-stone-300 hover:text-white flex items-center justify-center text-xs"
                          aria-label="Diminuir quantidade"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-mono tabular-nums px-2 text-white">
                          {cartItem.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(cartItem.item.id, 1)}
                          className="w-6 h-6 rounded-md bg-stone-800 text-stone-300 hover:text-white flex items-center justify-center text-xs"
                          aria-label="Aumentar quantidade"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveItem(cartItem.item.id)}
                      className="text-stone-400 hover:text-red-400 p-1.5 transition-colors"
                      aria-label={`Remover ${cartItem.item.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            {cart.length > 0 && (
              <div className="p-6 border-t border-white/10 bg-[#0C0A09]/80 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-stone-300 text-sm font-light">Total estimado</span>
                  <span className="text-xl font-mono font-bold text-white tabular-nums">
                    R$ {total.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <button
                  onClick={() => {
                    onProceedToContact();
                    onClose();
                  }}
                  className="w-full inline-flex items-center justify-center gap-2 py-4 px-6 rounded-full text-sm font-semibold text-white bg-[#E31837] hover:bg-[#c9122f] active:scale-[0.98] transition-all shadow-xl shadow-[#E31837]/25 cursor-pointer"
                >
                  <span>Avançar para contato</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};
