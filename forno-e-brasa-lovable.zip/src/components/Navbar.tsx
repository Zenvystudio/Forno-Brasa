import React, { useState } from 'react';
import { ShoppingBag, Menu as MenuIcon, X } from 'lucide-react';
import { CartItem } from '../types';

interface NavbarProps {
  cart: CartItem[];
  onOpenCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ cart, onOpenCart }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0C0A09]/90 backdrop-blur-md border-b border-white/5 transition-all">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <a 
          href="#inicio" 
          className="text-2xl font-serif font-bold tracking-tight text-[#F5F5F4] hover:text-[#E31837] transition-colors whitespace-nowrap shrink-0"
        >
          Forno & Brasa
        </a>

        {/* Zone 2: Navigation Links (4-5 concise single-line links) */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-stone-300">
          <a href="#inicio" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Início
          </a>
          <a href="#cardapio" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Cardápio
          </a>
          <a href="#tradicao" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Tradição
          </a>
          <a href="#contato" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Contato
          </a>
        </nav>

        {/* Zone 3: 1 Primary Action + Cart Trigger */}
        <div className="flex items-center gap-4 shrink-0">
          <button
            onClick={onOpenCart}
            aria-label="Ver itens do pedido"
            className="relative p-2.5 rounded-full text-stone-300 hover:text-white hover:bg-stone-800/60 transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-5 h-5" />
            {totalItems > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#E31837] text-white text-xs font-semibold flex items-center justify-center tabular-nums">
                {totalItems}
              </span>
            )}
          </button>

          <a
            href="#contato"
            className="hidden sm:inline-flex items-center justify-center px-6 py-2.5 rounded-full text-sm font-semibold text-white bg-[#E31837] hover:bg-[#c9122f] active:scale-[0.98] transition-all duration-200 whitespace-nowrap shrink-0 shadow-lg shadow-[#E31837]/20"
          >
            Entrar em contato
          </a>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-stone-300 hover:text-white focus:outline-none"
            aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#141211] border-b border-white/10 px-6 py-6 flex flex-col gap-4 text-base font-medium">
          <a
            href="#inicio"
            onClick={() => setMobileMenuOpen(false)}
            className="text-stone-300 hover:text-white transition-colors py-2"
          >
            Início
          </a>
          <a
            href="#cardapio"
            onClick={() => setMobileMenuOpen(false)}
            className="text-stone-300 hover:text-white transition-colors py-2"
          >
            Cardápio
          </a>
          <a
            href="#tradicao"
            onClick={() => setMobileMenuOpen(false)}
            className="text-stone-300 hover:text-white transition-colors py-2"
          >
            Tradição
          </a>
          <a
            href="#contato"
            onClick={() => setMobileMenuOpen(false)}
            className="text-stone-300 hover:text-white transition-colors py-2"
          >
            Contato
          </a>
          <a
            href="#contato"
            onClick={() => setMobileMenuOpen(false)}
            className="inline-flex items-center justify-center w-full px-5 py-3 rounded-full text-sm font-semibold text-white bg-[#E31837] hover:bg-[#c9122f] transition-colors mt-2"
          >
            Entrar em contato
          </a>
        </div>
      )}
    </header>
  );
};
