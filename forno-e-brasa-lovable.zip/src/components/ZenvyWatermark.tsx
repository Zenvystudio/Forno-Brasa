import React from 'react';

export const ZenvyWatermark: React.FC = () => {
  return (
    <div 
      className="fixed bottom-5 right-5 z-40 pointer-events-auto select-none"
      aria-label="Marca d'água Zenvy"
    >
      <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#12100E]/80 hover:bg-[#1A1715] backdrop-blur-md border border-white/10 text-stone-400 hover:text-white transition-all duration-300 shadow-xl group">
        <span className="w-1.5 h-1.5 rounded-full bg-[#E31837] group-hover:bg-[#EA580C] transition-colors" />
        <span className="text-[11px] font-sans font-semibold tracking-wider uppercase text-stone-300 group-hover:text-white transition-colors">
          zenvy
        </span>
      </div>
    </div>
  );
};
