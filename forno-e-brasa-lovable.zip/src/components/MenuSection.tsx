import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Check } from 'lucide-react';
import { MENU_ITEMS } from '../data/menu';
import { MenuItem } from '../types';

interface MenuSectionProps {
  onAddToCart: (item: MenuItem) => void;
  cartItemIds: Set<string>;
}

export const MenuSection: React.FC<MenuSectionProps> = ({ onAddToCart, cartItemIds }) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'classicas' | 'especiais'>('all');

  const filteredItems = MENU_ITEMS.filter((item) => {
    if (activeCategory === 'all') return true;
    return item.category === activeCategory;
  });

  return (
    <section id="cardapio" className="py-24 sm:py-32 px-6 sm:px-8 max-w-7xl mx-auto border-t border-white/5">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#EA580C] font-semibold block mb-3">
            Cardápio Digital
          </span>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-white text-balance tracking-tight">
            Nossas criações na brasa.
          </h2>
          <p className="mt-4 text-stone-400 text-base max-w-xl">
            Ingredientes autênticos e farinha nobre sobre massa fermentada por 48 horas.
          </p>
        </div>

        {/* Category Filter - Segmented Interactive Control (Button based, compliant with zero-pill rule) */}
        <div className="inline-flex items-center p-1.5 bg-stone-900/80 border border-white/10 rounded-xl self-start md:self-auto">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'all'
                ? 'bg-[#E31837] text-white shadow-md'
                : 'text-stone-400 hover:text-white'
            }`}
          >
            Todas as pizzas
          </button>
          <button
            onClick={() => setActiveCategory('classicas')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'classicas'
                ? 'bg-[#E31837] text-white shadow-md'
                : 'text-stone-400 hover:text-white'
            }`}
          >
            Clássicas
          </button>
          <button
            onClick={() => setActiveCategory('especiais')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'especiais'
                ? 'bg-[#E31837] text-white shadow-md'
                : 'text-stone-400 hover:text-white'
            }`}
          >
            Especiais
          </button>
        </div>
      </div>

      {/* Menu Grid - 2 columns with generous cards and breathtaking food photography */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
        <AnimatePresence mode="popLayout">
          {filteredItems.map((pizza) => {
            const isAdded = cartItemIds.has(pizza.id);

            return (
              <motion.article
                key={pizza.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                className="group flex flex-col justify-between bg-[#141211] rounded-2xl sm:rounded-3xl border border-white/5 overflow-hidden hover:border-white/15 transition-all duration-300"
              >
                {/* Large Photography with Fallback container */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-stone-900">
                  <img
                    src={pizza.image}
                    alt={pizza.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      // Fallback container ensures zero broken images
                      const target = e.currentTarget;
                      target.style.display = 'none';
                      if (target.parentElement) {
                        target.parentElement.classList.add('bg-gradient-to-br', 'from-stone-900', 'to-stone-800', 'flex', 'items-center', 'justify-center');
                      }
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#141211] via-transparent to-transparent opacity-80" />

                  {/* Clean Tabular Price Tag */}
                  <div className="absolute top-4 right-4 backdrop-blur-md bg-black/60 px-3.5 py-1.5 rounded-full border border-white/10 text-white font-mono font-medium text-sm tabular-nums">
                    R$ {pizza.price.toFixed(2).replace('.', ',')}
                  </div>
                </div>

                {/* Content Details */}
                <div className="p-6 sm:p-8 flex flex-col flex-1 justify-between">
                  <div>
                    <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white mb-2">
                      {pizza.name}
                    </h3>
                    <p className="text-stone-300 text-sm leading-relaxed mb-4">
                      {pizza.description}
                    </p>

                    {/* Zero-Pill Ingredient Separators */}
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-stone-400 font-light mb-6">
                      {pizza.ingredients.map((ingredient, idx) => (
                        <React.Fragment key={idx}>
                          <span>{ingredient}</span>
                          {idx < pizza.ingredients.length - 1 && (
                            <span className="text-[#EA580C]" aria-hidden="true">·</span>
                          )}
                        </React.Fragment>
                      ))}
                    </div>
                  </div>

                  {/* Functional Action */}
                  <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                    <span className="text-xs text-stone-400">
                      Tamanho único · 8 fatias (35cm)
                    </span>

                    <button
                      onClick={() => onAddToCart(pizza)}
                      className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-semibold transition-all duration-200 cursor-pointer ${
                        isAdded
                          ? 'bg-[#EA580C] text-white hover:bg-[#c2410c]'
                          : 'bg-white/10 text-white hover:bg-[#E31837] active:scale-95'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Adicionado</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>Adicionar ao pedido</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </AnimatePresence>
      </div>
    </section>
  );
};
