import React from 'react';
import { Flame } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-white/5 bg-[#080706] py-16 px-6 sm:px-8 text-stone-400 text-sm">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
        {/* Brand identity */}
        <div className="flex flex-col items-center md:items-start gap-2">
          <div className="flex items-center gap-2 text-white font-serif text-xl font-bold">
            <Flame className="w-5 h-5 text-[#E31837]" />
            <span>Pizzaria Forno & Brasa</span>
          </div>
          <p className="text-xs text-stone-400 font-light">
            A tradição do fogo a lenha e da fermentação lenta.
          </p>
        </div>

        {/* Navigation links */}
        <nav className="flex flex-wrap items-center justify-center gap-8 text-xs uppercase tracking-wider font-medium text-stone-400">
          <a href="#inicio" className="hover:text-white transition-colors">
            Início
          </a>
          <a href="#cardapio" className="hover:text-white transition-colors">
            Cardápio
          </a>
          <a href="#tradicao" className="hover:text-white transition-colors">
            Tradição
          </a>
          <a href="#contato" className="hover:text-white transition-colors">
            Contato
          </a>
        </nav>

        {/* Minimal Copyright & Watermark */}
        <div className="flex flex-col sm:flex-row items-center gap-2 text-xs text-stone-400 font-light">
          <span>© {new Date().getFullYear()} Forno & Brasa.</span>
          <span className="hidden sm:inline" aria-hidden="true">·</span>
          <span>Desenvolvido com <span className="font-semibold text-stone-300">zenvy</span></span>
        </div>
      </div>
    </footer>
  );
};
