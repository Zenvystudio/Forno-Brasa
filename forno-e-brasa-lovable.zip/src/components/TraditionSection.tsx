import React from 'react';
import { motion } from 'motion/react';
import { Flame, Clock, Sparkles } from 'lucide-react';

export const TraditionSection: React.FC = () => {
  return (
    <section id="tradicao" className="py-24 sm:py-32 px-6 sm:px-8 max-w-7xl mx-auto border-t border-white/5">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column: Asymmetrical Editorial Narrative */}
        <div className="lg:col-span-6 flex flex-col justify-between">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#EA580C] font-semibold block mb-3">
              Tradição & Método
            </span>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-white tracking-tight leading-[1.08] text-balance mb-6">
              Paciência no tempo, precisão no fogo.
            </h2>
            <p className="text-stone-300 text-lg font-light leading-relaxed mb-10 max-w-xl">
              Nossa massa descansa por dois dias inteiros antes de encontrar as labaredas a 450°C. O resultado é leveza absoluta, digestão suave e aroma inconfundível.
            </p>
          </div>

          {/* Genuine Authentic Metrics (Tabular numerals, no fake badges) */}
          <div className="grid grid-cols-3 gap-6 pt-8 border-t border-white/10">
            <div>
              <div className="flex items-center gap-1.5 text-stone-400 text-xs mb-1">
                <Clock className="w-3.5 h-3.5 text-[#EA580C]" />
                <span>Maturação</span>
              </div>
              <div className="text-3xl sm:text-4xl font-serif font-bold text-white tabular-nums">
                48h
              </div>
              <p className="text-xs text-stone-400 mt-1 font-light">
                Levedura natural viva
              </p>
            </div>

            <div>
              <div className="flex items-center gap-1.5 text-stone-400 text-xs mb-1">
                <Flame className="w-3.5 h-3.5 text-[#E31837]" />
                <span>Forno a Lenha</span>
              </div>
              <div className="text-3xl sm:text-4xl font-serif font-bold text-[#E31837] tabular-nums">
                450°C
              </div>
              <p className="text-xs text-stone-400 mt-1 font-light">
                Cocção em 90 segundos
              </p>
            </div>

            <div>
              <div className="flex items-center gap-1.5 text-stone-400 text-xs mb-1">
                <Sparkles className="w-3.5 h-3.5 text-[#EA580C]" />
                <span>Farinha</span>
              </div>
              <div className="text-3xl sm:text-4xl font-serif font-bold text-white tabular-nums">
                100%
              </div>
              <p className="text-xs text-stone-400 mt-1 font-light">
                Grano duro tipo 00
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Editorial Visual Composition */}
        <div className="lg:col-span-6 relative">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="relative rounded-3xl overflow-hidden border border-white/10 shadow-2xl bg-stone-900"
          >
            <div className="aspect-[4/3] w-full">
              <img
                src="/src/assets/images/pizza_calabresa_artesanal_1792173843706.jpg"
                alt="Detalhe da pizza artesanal assada com borda aerada no forno da Pizzaria Forno & Brasa"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            
            <div className="absolute bottom-6 left-6 right-6">
              <p className="text-xs uppercase tracking-widest text-[#EA580C] font-semibold mb-1">
                Bordas Leopardadas
              </p>
              <p className="text-sm text-stone-200 font-light">
                O choque térmico do forno cria as micro-bolhas crocantes que definem a autêntica pizza napolitana.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
