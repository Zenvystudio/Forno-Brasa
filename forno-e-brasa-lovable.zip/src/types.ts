export interface MenuItem {
  id: string;
  name: string;
  category: 'classicas' | 'especiais' | 'doces';
  tag?: string;
  description: string;
  price: number;
  image: string;
  ingredients: string[];
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
  notes?: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  intent: 'pedido' | 'duvida' | 'evento';
  message: string;
}
