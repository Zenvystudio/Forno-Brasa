import { MenuItem } from '../types';

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'margherita',
    name: 'Margherita Verace',
    category: 'classicas',
    description: 'Molho San Marzano D.O.P., mozzarella fior di latte, manjericão fresco e azeite extravirgem.',
    price: 68,
    image: '/src/assets/images/pizza_margherita_1792173841761.jpg',
    ingredients: ['San Marzano D.O.P.', 'Fior di Latte', 'Manjericão Fresco', 'Azeite Extravirgem']
  },
  {
    id: 'pepperoni',
    name: 'Pepperoni Brasa',
    category: 'especiais',
    description: 'Fatias crocantes de pepperoni artesanal, mozzarella derretida e toque sutil de pimenta da casa.',
    price: 76,
    image: '/src/assets/images/pizza_pepperoni_1792173842883.jpg',
    ingredients: ['Pepperoni Artesanal', 'Mozzarella Especial', 'Molho de Tomate Rústico', 'Flocos de Pimenta']
  },
  {
    id: 'quatro-queijos',
    name: 'Quatro Queijos Nobres',
    category: 'classicas',
    description: 'Gorgonzola cremoso, fior di latte, fontina alpina e lascas maturadas de parmesão.',
    price: 78,
    image: '/src/assets/images/pizza_quatro_queijos_1792173843654.jpg',
    ingredients: ['Gorgonzola', 'Fior di Latte', 'Fontina', 'Parmesão Maturado']
  },
  {
    id: 'calabresa',
    name: 'Calabresa Defumada',
    category: 'especiais',
    description: 'Linguiça calabresa artesanal levemente defumada, cebola roxa caramelizada e azeitonas pretas.',
    price: 72,
    image: '/src/assets/images/pizza_calabresa_artesanal_1792173843706.jpg',
    ingredients: ['Calabresa Defumada', 'Cebola Roxa', 'Azeitonas Pretas', 'Orégano Fresco']
  }
];
